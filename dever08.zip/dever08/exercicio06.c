#include <stdio.h>

int main() {
    char resposta;

    do {
        int mes, ano, dias;

        
        printf("Digite o mês (1 a 12): ");
        scanf("%d", &mes);

        if (mes < 1 || mes > 12) {
            printf("Mês inválido. Tente novamente.\n");
            continue;
        }

        printf("Digite o ano: ");
        scanf("%d", &ano);

        if (ano <= 0) {
            printf("Ano inválido. Tente novamente.\n");
            continue;
        }

        
        switch (mes) {
            case 4:
            case 6:
            case 9:
            case 11:
                dias = 30;
                break;
            case 2:
                if ((ano % 4 == 0 && ano % 100 != 0) || ano % 400 == 0) {
                    dias = 29; // Ano bissexto
                } else {
                    dias = 28;
                }
                break;
            default:
                dias = 31;
                break;
        }

        
        printf("O mês %d do ano %d tem %d dias.\n", mes, ano, dias);

        
        printf("VOCÊ DESEJA OUTRAS ENTRADAS (S/?)? ");
        scanf(" %c", &resposta);

    } while (resposta == 'S' || resposta == 's');

    return 0;
}
